package pet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class LoginDAO {
	static int status=0;
	public static int Save(LoginAction RA) throws ClassNotFoundException,SQLException
	{
	Class.forName("com.mysql.jdbc.Driver");
	Connection conn = null;
	try
	{
	conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/petfeeder","root","");
	}
	catch(Exception e)
	{
	System.out.print(e);
	}
	PreparedStatement preparedStatement = conn.prepareStatement("select * from signup where username = ? and password = ?");
	
		preparedStatement.setString(1, RA.getUsername());
	preparedStatement.setString(2, RA.getPassword());
	ResultSet rs = preparedStatement.executeQuery();
	if(rs.next())
	{
		status = 1;
		return status;
	}
	else
	{
		status = 0;
		return status;
	}
}
}


