package pet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterDAO {
static int status=0;
public static int Save(RegisterAction RA) throws ClassNotFoundException,SQLException
{
Class.forName("com.mysql.jdbc.Driver");
Connection conn = null;
try
{
conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/petfeeder","root","");
}
catch(Exception e)
{
System.out.print(e);
}
PreparedStatement pstatement = null;
String insert_into = "insert into signup values(?,?)";
pstatement = conn.prepareStatement(insert_into);
pstatement.setString(1, RA.getUsername());
pstatement.setString(2, RA.getPassword());
status = pstatement.executeUpdate();
return status;
}
}